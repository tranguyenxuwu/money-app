import 'package:flutter/material.dart';

void main() => runApp(new MyApp() as Widget);

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'Flutter Demo',
      theme: new ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: new MyHomePage(title: 'Cars'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text(this.title),
      ),
      body: new ListView(
        children: <Widget>[
          CarWidget(
            "Toyota",
            "Raize",
            "https://hips.hearstapps.com/hmg-prod/images/2025-mazda-3-carbon-edition-101-67d04090393f8.jpg",
          ),
          CarWidget(
            "Kia",
            "Seltos",
            "https://hips.hearstapps.com/hmg-prod/images/2025-mazda-3-carbon-edition-101-67d04090393f8.jpg",
          ),
          CarWidget(
            "Ford",
            "Ranger",
            "https://hips.hearstapps.com/hmg-prod/images/2025-mazda-3-carbon-edition-101-67d04090393f8.jpg",
          ),
          CarWidget(
            "Mazda",
            "Mazda 3",
            "https://hips.hearstapps.com/hmg-prod/images/2025-mazda-3-carbon-edition-101-67d04090393f8.jpg",
          ),
        ],
      ),
    );
  }
}

class CarWidget extends StatelessWidget {
  CarWidget(this.make, this.model, this.imageSrc) : super();
  final String make;
  final String model;
  final String imageSrc;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(20.0),
      child: Container(
        padding: EdgeInsets.all(20.0),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black, width: 2.0),
      ),
        child: Center(
          child: Column(
            children: <Widget>[
              Text("${make} ${model}",
                  style: TextStyle(
                    fontSize: 24.0)),
              Padding(padding: EdgeInsets.only(top: 20.0),
              child: Image.network(imageSrc)),
            ],
          ),
        ),
    ));
  }
}