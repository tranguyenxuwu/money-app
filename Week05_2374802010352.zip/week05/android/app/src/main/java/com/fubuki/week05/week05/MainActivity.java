package com.fubuki.week05.week05;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
